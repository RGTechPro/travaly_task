import 'dart:convert';
import 'dart:developer' as developer;
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:http/http.dart' as http;
import '../../../../core/error/exceptions.dart';
import '../models/hotel_model.dart';

abstract class HotelRemoteDataSource {
  Future<List<HotelModel>> searchHotels(String query, int page);
  Future<List<HotelModel>> getPopularHotels({
    required String city,
    required String state,
    required String country,
  });
}

class HotelRemoteDataSourceImpl implements HotelRemoteDataSource {
  final http.Client client;
  static const String baseUrl = 'https://api.mytravaly.com/public/v1/';
  static const String authToken = '71523fdd8d26f585315b4233e39d9263';

  String? _visitorToken;

  HotelRemoteDataSourceImpl({required this.client});

  Future<void> _ensureVisitorToken() async {
    if (_visitorToken != null) return;

    try {
      developer.log('Registering device...', name: 'HotelAPI');

      // Get real device info
      final deviceInfo = DeviceInfoPlugin();
      Map<String, dynamic> deviceData = {};

      if (Platform.isAndroid) {
        final androidInfo = await deviceInfo.androidInfo;
        deviceData = {
          'deviceModel': androidInfo.model,
          'deviceFingerprint': androidInfo.fingerprint,
          'deviceBrand': androidInfo.brand,
          'deviceId': androidInfo.id,
          'deviceName':
              '${androidInfo.model}_${androidInfo.version.release}_${androidInfo.display}',
          'deviceManufacturer': androidInfo.manufacturer,
          'deviceProduct': androidInfo.product,
          'deviceSerialNumber': androidInfo.serialNumber.isNotEmpty
              ? androidInfo.serialNumber
              : 'unknown',
        };
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfo.iosInfo;
        deviceData = {
          'deviceModel': iosInfo.model,
          'deviceBrand': 'Apple',
          'deviceId': iosInfo.identifierForVendor ?? 'unknown',
          'deviceName': iosInfo.name,
          'deviceManufacturer': 'Apple',
          'deviceProduct': iosInfo.utsname.machine,
          'deviceSerialNumber': 'unknown',
        };
      } else {
        // Fallback for other platforms
        deviceData = {
          'deviceModel': 'Flutter App',
          'deviceBrand': 'MyTravaly',
          'deviceId': 'flutter_${DateTime.now().millisecondsSinceEpoch}',
          'deviceName': 'Flutter Device',
          'deviceManufacturer': 'Flutter',
          'deviceProduct': 'FlutterApp',
          'deviceSerialNumber': 'unknown',
        };
      }

      developer.log('Device Info: ${json.encode(deviceData)}',
          name: 'HotelAPI');

      final response = await client.post(
        Uri.parse(baseUrl),
        headers: {
          'authtoken': authToken,
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'action': 'deviceRegister',
          'deviceRegister': deviceData,
        }),
      );

      developer.log('Device register response: ${response.statusCode}',
          name: 'HotelAPI');
      developer.log('Response body: ${response.body}', name: 'HotelAPI');

      if (response.statusCode == 201 || response.statusCode == 200) {
        final data = json.decode(response.body);
        _visitorToken = data['data']?['visitorToken'];
        developer.log('Visitor token obtained: $_visitorToken',
            name: 'HotelAPI');
      } else {
        developer.log('Failed to get visitor token: ${response.statusCode}',
            name: 'HotelAPI');
      }
    } catch (e) {
      developer.log('Device register error: $e', name: 'HotelAPI');
      // Continue without visitor token
    }
  }

  @override
  Future<List<HotelModel>> searchHotels(String query, int page) async {
    await _ensureVisitorToken();

    try {
      developer.log('Searching hotels: "$query" (page: $page)',
          name: 'HotelAPI');

      final requestBody = {
        'action': 'searchAutoComplete',
        'searchAutoComplete': {
          'inputText': query,
          'searchType': [
            'byCity',
            'byState',
            'byCountry',
            'byPropertyName',
          ],
          'limit': 10,
        }
      };

      developer.log('Request: ${json.encode(requestBody)}',
          name: 'HotelAPI');

      final response = await client.post(
        Uri.parse(baseUrl),
        headers: {
          'authtoken': authToken,
          if (_visitorToken != null) 'visitortoken': _visitorToken!,
          'Content-Type': 'application/json',
        },
        body: json.encode(requestBody),
      );

      developer.log('Search response: ${response.statusCode}',
          name: 'HotelAPI');
      developer.log('Response body: ${response.body}', name: 'HotelAPI');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List<HotelModel> hotels = [];

        if (data['data']?['autoCompleteList'] != null) {
          final autoCompleteList = data['data']['autoCompleteList'];

          if (autoCompleteList['byPropertyName']?['present'] == true) {
            final properties =
                autoCompleteList['byPropertyName']['listOfResult'] as List? ??
                    [];
            developer.log('Found ${properties.length} properties',
                name: 'HotelAPI');

            hotels.addAll(
              properties.map((prop) => HotelModel.fromJson({
                    'propertyCode': prop['searchArray']?['query']?[0],
                    'propertyName': prop['propertyName'],
                    'propertyAddress': {
                      'city': prop['address']?['city'],
                      'state': prop['address']?['state'],
                      'country': 'India',
                    },
                    'description': prop['valueToDisplay'],
                  })),
            );
          } else {
            developer.log('No properties found in response',
                name: 'HotelAPI');
          }
        }

        return hotels;
      } else {
        developer.log('Search failed: ${response.statusCode}',
            name: 'HotelAPI');
        throw ServerException('Failed to search hotels');
      }
    } catch (e) {
      developer.log('Search error: $e', name: 'HotelAPI');
      if (e is ServerException) rethrow;
      throw NetworkException('Network error occurred');
    }
  }

  @override
  Future<List<HotelModel>> getPopularHotels({
    required String city,
    required String state,
    required String country,
  }) async {
    await _ensureVisitorToken();

    try {
      developer.log('Getting popular hotels: $city, $state, $country',
          name: 'HotelAPI');

      final requestBody = {
        'action': 'popularStay',
        'popularStay': {
          'limit': 10,
          'entityType': 'Any',
          'filter': {
            'searchType': 'byCity',
            'searchTypeInfo': {
              'country': country,
              'state': state,
              'city': city,
            }
          },
          'currency': 'INR',
        }
      };

      developer.log('Request: ${json.encode(requestBody)}',
          name: 'HotelAPI');

      final response = await client.post(
        Uri.parse(baseUrl),
        headers: {
          'authtoken': authToken,
          if (_visitorToken != null) 'visitortoken': _visitorToken!,
          'Content-Type': 'application/json',
        },
        body: json.encode(requestBody),
      );

      developer.log('Popular hotels response: ${response.statusCode}',
          name: 'HotelAPI');
      developer.log('Response body: ${response.body}', name: 'HotelAPI');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == true && data['data'] != null) {
          final List hotelsData = data['data'] as List;
          developer.log('Found ${hotelsData.length} popular hotels',
              name: 'HotelAPI');
          return hotelsData.map((hotel) => HotelModel.fromJson(hotel)).toList();
        }
        developer.log('No popular hotels data in response',
            name: 'HotelAPI');
        return [];
      } else {
        developer.log('Get popular hotels failed: ${response.statusCode}',
            name: 'HotelAPI');
        throw ServerException('Failed to get popular hotels');
      }
    } catch (e) {
      developer.log('Get popular hotels error: $e', name: 'HotelAPI');
      if (e is ServerException) rethrow;
      throw NetworkException('Network error occurred');
    }
  }
}
